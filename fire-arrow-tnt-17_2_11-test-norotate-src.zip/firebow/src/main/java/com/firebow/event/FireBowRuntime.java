package com.firebow.event;

import com.firebow.util.AsyncRunner;
import com.firebow.util.InteractionUtil;
import com.firebow.util.InventoryUtil;
import com.firebow.util.PingUtil;
import com.firebow.util.SearchResult;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v11 — không xoay camera.
 *
 *   SEND    : đặt rail khi tâm ngắm đã trỏ đủ gần điểm nền → sang CART
 *   CART    : đặt cart khi tâm ngắm đã trỏ đủ gần rail → sang CONFIRM
 *   CONFIRM : chờ ping/50+2 tick, cart phải spawn. Không spawn → SEND lại (tối đa MAX_PLACE_ATTEMPTS)
 *
 * Mỗi tick chỉ kiểm tra, không đổi yaw/pitch. Nếu người chơi không nhìn về điểm đặt
 * thì bước đó chờ tới MAX_WAIT rồi bỏ.
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_WAIT          = 20;   // tick chờ điều kiện trước mỗi bước
    private static final int  MAX_JOB_TICKS      = 120;
    private static final int  MAX_CONFIRM_TICKS  = 20;

    private enum Phase { SEND, CART, CONFIRM }

    private static final class RailJob {
        final BlockPos pos;
        Phase phase       = Phase.SEND;
        int   attempts    = 0;  // số lần interact đặt rail
        int   ticks       = 0;  // tick đếm trong phase hiện tại
        int   window      = 0;  // số tick chờ trong CONFIRM
        int   totalTicks  = 0;
        int   cartsBefore = 0;  // số cart quanh rail trước khi đặt

        RailJob(BlockPos pos) { this.pos = pos; }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private volatile boolean enabled = true;
    private RailJob job = null;  // chỉ đọc/ghi trên main thread

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── Arrow tick: nhận yêu cầu đặt rail ──────────────────────────────────

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);

        job = new RailJob(railPos);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                return;
            }
            if (!enabled) {
                if (job != null) abort(mc);
                return;
            }
            if (job != null) stepJob(mc);
        } finally {
            // không còn góc tạm nào để trả lại
        }
    }

    private void stepJob(MinecraftClient mc) {
        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(mc); return; }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                if (railThere) { enter(j, Phase.CART, 0); return; }

                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(mc); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> { j.attempts++; enter(j, Phase.CART, 0); }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(mc); }
                    case INVALID   -> abort(mc);
                }
            }

            case CART -> {
                if (!railThere) { revert(mc, j); return; }

                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { abort(mc); return; }

                int before = countCarts(mc, j.pos);
                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    j.cartsBefore = before;
                    enter(j, Phase.CONFIRM, verifyWindow(mc));
                } else if (j.ticks > MAX_WAIT) {
                    abort(mc);
                }
            }

            case CONFIRM -> {
                if (j.ticks < j.window) return;
                if (countCarts(mc, j.pos) > j.cartsBefore) { job = null; return; }
                // cart không spawn → server từ chối rail/cart
                revert(mc, j);
            }
        }
    }

    private void revert(MinecraftClient mc, RailJob j) {
        if (j.attempts >= MAX_PLACE_ATTEMPTS) { abort(mc); return; }
        enter(j, Phase.SEND, 0);
    }

    private static void enter(RailJob j, Phase phase, int window) {
        j.phase  = phase;
        j.ticks  = 0;
        j.window = window;
    }

    private static int verifyWindow(MinecraftClient mc) {
        long ping = PingUtil.getPingMs(mc);
        return (int) Math.min(MAX_CONFIRM_TICKS, ping / 50L + 2L);
    }

    private void abort(MinecraftClient mc) {
        job = null;
    }

    private static int countCarts(MinecraftClient mc, BlockPos pos) {
        Box box = new Box(pos.getX(), pos.getY(), pos.getZ(),
                          pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1).expand(1.0);
        return mc.world.getEntitiesByClass(TntMinecartEntity.class, box, e -> true).size();
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }
}
