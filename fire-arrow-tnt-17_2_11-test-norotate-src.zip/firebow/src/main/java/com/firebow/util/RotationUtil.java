package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * RotationUtil v11 — KHÔNG xoay camera, không gửi góc giả.
 *
 * Chỉ tính điểm hit và kiểm tra tâm ngắm hiện tại có đủ gần điểm đó không.
 * Đặt block chỉ khi tâm ngắm đã nằm trong AIM_TOLERANCE_DEG.
 */
public final class RotationUtil {
    private RotationUtil() {}

    /** Sai số tối đa giữa tâm ngắm và điểm hit (độ). Chỉnh tại đây. */
    public static final double AIM_TOLERANCE_DEG = 30.0;

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    /** Góc (độ) giữa hướng nhìn hiện tại và hướng tới target. */
    public static double aimErrorDeg(ClientPlayerEntity p, Vec3d target) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d dir  = target.subtract(p.getEyePos()).normalize();
        double dot = Math.max(-1.0, Math.min(1.0, look.dotProduct(dir)));
        return Math.toDegrees(Math.acos(dot));
    }

    public static boolean isAimed(ClientPlayerEntity p, Vec3d target) {
        return aimErrorDeg(p, target) <= AIM_TOLERANCE_DEG;
    }
}
