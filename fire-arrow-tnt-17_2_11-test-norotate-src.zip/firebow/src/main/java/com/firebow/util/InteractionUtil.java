package com.firebow.util;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v11 — không xoay camera.
 *
 * Mọi điều kiện đều kiểm tra tại thời điểm interact: reach, không đang dùng cung,
 * và tâm ngắm đã trỏ đủ gần điểm hit.
 * Đổi slot chỉ đổi field phía client, vanilla sync khi interact.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    public enum Result { SENT, NOT_READY, INVALID }

    public static boolean railReady(MinecraftClient mc, ClientPlayerEntity p, BlockPos railPos) {
        if (mc.world == null || mc.interactionManager == null) return false;
        if (p.isUsingItem() || !inReach(p, railPos))          return false;
        if (!mc.world.getBlockState(railPos).isAir())         return false;
        if (!PlacementCalc.isSolidGround(mc.world, railPos.down())) return false;
        return RotationUtil.isAimed(p, RotationUtil.calcHitVec(railPos.down(), Direction.UP));
    }

    public static boolean cartReady(MinecraftClient mc, ClientPlayerEntity p, BlockPos railPos) {
        if (mc.world == null || mc.interactionManager == null) return false;
        if (p.isUsingItem() || !inReach(p, railPos))          return false;
        var s = mc.world.getBlockState(railPos);
        if (!(s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL))) return false;
        return RotationUtil.isAimed(p, RotationUtil.calcHitVec(railPos, Direction.UP));
    }

    public static Result executeRail(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return Result.INVALID;

        BlockPos ground = railPos.down();
        if (!mc.world.getBlockState(railPos).isAir())       return Result.INVALID;
        if (!PlacementCalc.isSolidGround(mc.world, ground)) return Result.INVALID;
        if (!railReady(mc, p, railPos))                     return Result.NOT_READY;

        Vec3d hitVec = RotationUtil.calcHitVec(ground, Direction.UP);
        int origSlot = p.getInventory().selectedSlot;

        p.getInventory().selectedSlot = railSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, ground, false));
        p.getInventory().selectedSlot = origSlot;
        return Result.SENT;
    }

    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        if (!cartReady(mc, p, railPos)) return false;

        Vec3d hitVec = RotationUtil.calcHitVec(railPos, Direction.UP);
        int origSlot = p.getInventory().selectedSlot;

        p.getInventory().selectedSlot = cartSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        p.getInventory().selectedSlot = origSlot;
        return true;
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
